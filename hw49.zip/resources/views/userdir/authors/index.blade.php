@extends('base')
@section('content')
    <div class="container">
        <h1>Книжный магазин "Раритет"</h1>
        <p>Жанр на выбор</p>

{{--        <a href="{{route('authors.')}}"></a>--}}
    </div>



@endsection
