<?php $__env->startSection('content'); ?>
    <div class="container">
        <p>Жанр на выбор</p>
        <div class="container inline-block">
            <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card inline-block mr-5" style="width: 18rem; display: inline-block">
                <div class="card-header text-center">
                   Genre
                </div>
                <a class="nav-link" href="<?php echo e(route('genres.show', ['genre' => $genre])); ?>">
                    <img class="card-img-top" height="400" src="<?php echo e(asset('/storage/' . $genre->image)); ?>" alt="<?php echo e($genre->image); ?>">
                </a>

                <div class="card-body border-top">
                    <a class="nav-link" href="<?php echo e(route('genres.show', ['genre' => $genre])); ?>"><?php echo e($genre->name); ?></a>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/admin/Documents/hw-49/resources/views/userdir/genre/index.blade.php ENDPATH**/ ?>