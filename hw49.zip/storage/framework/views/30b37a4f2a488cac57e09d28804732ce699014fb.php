<?php $__env->startSection('content'); ?>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <div class="container mb-4">
        <h2>Книжный магазин "РаРиТеТ"</h2>
    </div>

    <form class="mb-5" method="post" action="<?php echo e(route('admin.books.update', ['book' => $book])); ?>" enctype="multipart/form-data">
        <?php echo method_field('put'); ?>
        <?php echo csrf_field(); ?>
        <h1>Изменить книгу</h1>
        <div class="form-group">
            <label for="name">Название книги</label>
            <input type="text" class="form-control" id="name" name="name" value="<?php echo e($book->name); ?>">
        </div>

        <div class="form-group">
            <label for="description">Описание книги</label>
            <textarea class="form-control" id="description" name="description" ><?php echo e($book->description); ?></textarea>
        </div>

        <div class="form-group">
            <label for="author_id">Автор</label>
            <select name="author_id" class="custom-select">
                <?php $__currentLoopData = $authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($author->id); ?>"><?php echo e($author->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="form-group">
            <label for="genre_id">Жанр</label>
            <select name="genre_id" class="custom-select">
                <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($genre->id); ?>"><?php echo e($genre->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="form-group">
            <label for="price">Цена</label>
            <input class="form-control" id="price" name="price" value="<?php echo e($book->price); ?>">
        </div>

        <img src="<?php echo e(asset('/storage/' . $book->image)); ?>" alt="<?php echo e($book->image); ?>" style="width:110px;height:170px;">
        <br>
        <div class="form-group my-4">
            <div class="custom-file">
                <label class="custom-file-label" for="customFile">Choose file</label>
                <input type="file" class="custom-file-input form-control" id="customFile" name="image">
            </div>
        </div>

        <button type="submit" class="btn btn-primary">Принять изменения</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/admin/Documents/hw-49/resources/views/admin/book/edit.blade.php ENDPATH**/ ?>