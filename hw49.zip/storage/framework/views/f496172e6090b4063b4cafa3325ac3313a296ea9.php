<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Книжный магазин "Раритет"</h1>
        <p>Жанр на выбор</p>

        <a href="<?php echo e(route('userdir.')); ?>"></a>
    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/admin/Documents/hw-49/resources/views/userdir/index.blade.php ENDPATH**/ ?>