<?php $__env->startSection('content'); ?>
    <div class="container">
        <string><a href="<?php echo e(route('books.index')); ?>">Главная</a></string>
        <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($genre->id == $book->genre_id): ?>
                <a href="<?php echo e(route('genres.show', ['genre'=>$genre])); ?>">-><?php echo e($genre->name); ?></a>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        -><?php echo e($book->name); ?>

        <?php $__currentLoopData = $authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($book->author_id == $author->id): ?>
                <h1><a href="<?php echo e(route('authors.show', ['author' => $author])); ?>"><?php echo e($book->author->name); ?></a></h1>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <h2><?php echo e($book->name); ?></h2>

            <img class="mb-4 mr-5" height="460px"  style="display: inline-block" width="300px" src="<?php echo e(asset('/storage/' . $book->image)); ?>" alt="<?php echo e($book->image); ?>">
            <div class="ml-2" style="display: inline-block">

                <p style="display:block">Цена: <?php echo e($book->price); ?></p>
                <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($book->genre_id == $genre->id): ?>
                        <p style="display:block"> Genre: <?php echo e($genre->name); ?></p>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <hr>
            <p><?php echo e($book->description); ?></p>

    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/admin/Documents/hw-49/resources/views/userdir/books/show.blade.php ENDPATH**/ ?>