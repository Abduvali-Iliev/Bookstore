<?php $__env->startSection('content'); ?>
    <div class="container">
        <p><a href="<?php echo e(route('genres.index')); ?>">Главная</a>-><?php echo e($genre->name); ?></p>

        <h2><?php echo e($genre->name); ?></h2>
        <p><?php echo e($genre->description); ?></p>
    </div>


    <h1 class="m-4">Книги в этом жанре</h1>

    <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($book->genre_id == $genre->id): ?>
        <div class="card mr-5 mb-5" style="width: 18rem; display: inline-block;">
            <div class="card-header">Book <?php echo e($book->name); ?> detail </div>
            <a href="<?php echo e(route('books.show', ['book' => $book])); ?>">
            <img class="card-img-top" height="430px" src="<?php echo e(asset('/storage/' . $book->image)); ?>" alt="<?php echo e($book->image); ?>">
            </a>
            <div class="card-body">
                <h5 class="card-title"><?php echo e($book->name); ?></h5>
                <p class="card-text">
                    <?php echo e($book->author->name); ?>

                </p>
            </div>
            <footer class="blockquote-footer mb-3">
                Price: <?php echo e(number_format($book->price, 2)); ?>

            </footer>
        </div>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/admin/Documents/hw-49/resources/views/userdir/genre/show.blade.php ENDPATH**/ ?>