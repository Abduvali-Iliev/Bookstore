<?php $__env->startSection('content'); ?>
    <div class="container mb-4">
        <h2>Книжный магазин "РаРиТеТ"</h2>

    <div class="card " style="width: 18rem;">
        <div class="card-header">Детали книги: <?php echo e($book->name); ?></div>
        <img class="card-img-top" src="<?php echo e(asset('/storage/' . $book->image)); ?>" alt="<?php echo e($book->image); ?>">
        <div class="card-body">
            <h5 class="card-title"><?php echo e($book->name); ?></h5>
            <p class="card-text">
                <?php if(!is_null($book->description)): ?>
                    <?php echo e($book->description); ?>

                <?php else: ?>
                    No description
                <?php endif; ?>
            </p>
        </div>
        <footer class="blockquote-footer mb-3">
            Цена: <?php echo e(number_format($book->price, 2)); ?>

        </footer>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/admin/Documents/hw-49/resources/views/admin/book/show.blade.php ENDPATH**/ ?>