<?php $__env->startSection('content'); ?>
    <div class="container">
        <p>Жанр на выбор</p>
        <div class="container inline-block">
            <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card inline-block mr-5" style="width: 18rem; display: inline-block; object-fit: cover">
                    <div class="card-header text-center">
                        Genre
                    </div>
                    <a style="object-fit: cover" class="nav-link" href="<?php echo e(route('books.show', ['book' => $book])); ?>">
                        <img style="object-fit: cover" class="card-img-top" height="400" src="<?php echo e(asset('/storage/' . $book->image)); ?>" alt="<?php echo e($book->image); ?>">
                    </a>

                    <div class="card-body border-top">
                        <a class="nav-link" href="<?php echo e(route('books.show', ['book' => $book])); ?>"><?php echo e($book->name); ?></a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/admin/Documents/hw-49/resources/views/userdir/books/index.blade.php ENDPATH**/ ?>