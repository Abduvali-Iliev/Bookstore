<?php $__env->startSection('content'); ?>
    <div class="container">
        <string><a href="<?php echo e(route('books.index')); ?>">Главная</a></string>
        <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($genre->id == $book->genre_id): ?>
                <a href="<?php echo e(route('genres.show', ['genre'=>$genre])); ?>">-><?php echo e($genre->name); ?></a>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        -><?php echo e($book->name); ?>

        <?php $__currentLoopData = $authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($book->author_id == $author->id): ?>
                <h1><a href="<?php echo e(route('authors.show', ['author' => $author])); ?>"><?php echo e($book->author->name); ?></a></h1>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <h2><?php echo e($book->name); ?></h2>

        <img class="mb-4 mr-5" height="460px" style="display: inline-block" width="300px"
             src="<?php echo e(asset('/storage/' . $book->image)); ?>" alt="<?php echo e($book->image); ?>">
        <div class="ml-2" style="display: inline-block">

            <p style="display:block">Цена: <?php echo e($book->price); ?></p>
            <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($book->genre_id == $genre->id): ?>
                    <p style="display:block"> Genre: <?php echo e($genre->name); ?></p>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <hr>
        <p class="mb-5"><?php echo e($book->description); ?></p>


        <div class="comment-form mt-5 mb-5">
            <form id="create-comment" class="needs-validation" novalidate>
                <?php echo csrf_field(); ?>
                <input type="hidden" id="book_id" value="<?php echo e($book->id); ?>">
                <div class="form-group">
                    <label for="authorInput">Автор</label>
                    <input name="author" type="text" class="form-control" id="authorInput"
                           aria-describedby="authorHelpText"
                           required>
                    <div class="invalid-feedback">
                        Error
                    </div>
                    <small id="authorHelpText" class="form-text text-muted">Напишите свое имя.</small>
                </div>
                <div class="form-group">
                    <label for="commentFormControl">Коментарии</label>
                    <textarea name="body" class="form-control" id="commentFormControl" rows="3" required></textarea>
                    <div class="invalid-feedback">
                        Error
                    </div>
                </div>

                <div class="dropup-center dropup mt-4">
                    <label>
                        Оценка книги
                    </label>
                    <select class="form-select" aria-label="Default select example" name="score">
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option selected value="5">5</option>
                    </select>
                    <div class="invalid-feedback">
                        Error
                    </div>
                </div>

                <div class="text-center">
                    <button id="create-comment-btn" type="submit" class="mt-3 btn btn-outline-primary btn-sm btn-block">
                        Добавить коментарии
                    </button>
                </div>
            </form>





































        </div>

    </div>

    <button class="btn btn-outline-secondary mb-4 btn-lg d-block mx-auto" data-bs-toggle="collapse" data-bs-target="#commentCollapse"
            aria-expanded="false" aria-controls="commentCollapse">All comments</button>


    <div class="scrollit collapse multi-collapse" id="commentCollapse" >
        <?php $__currentLoopData = $book->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card mb-4">
                <div class="card-header">
                    Автор:
                    <string class="text-primary"><?php echo e($comment->author); ?></string>
                </div>
                <div class="card-body">
                    <blockquote class="blockquote mb-0">
                        <p><?php echo e($comment->body); ?></p>
                        <footer class="blockquote-footer">Оценка <cite title="Source Title"><?php echo e($comment->score); ?></cite>
                        </footer>
                    </blockquote>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>


<?php $__env->stopSection(); ?>






<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/admin/Documents/hw-49/resources/views/userdir/books/show.blade.php ENDPATH**/ ?>